const db = require('mongoose');
db.connect('mongodb+srv://shadkill:LmM6fm4H0kGa5sY5@cluster0.o0yn5uy.mongodb.net/jongler?retryWrites=true&w=majority&appName=Cluster0');
module.exports =db;